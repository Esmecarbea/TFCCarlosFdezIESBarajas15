Case for Freenove ESP32-S3-WROOM CAM Board by BurningAfter on Thingiverse: https://www.thingiverse.com/thing:6028595

Summary:
This is a case for the Freenove ESP32-S3-WROOM CAM Board.Pretty snug fit, so you need to get your printer's tolerances in order.BOM:4x M2 threaded insert4x M2x8mmNo support's required. Print using 4mm Nozzle and &lt;=.24mm layer height
